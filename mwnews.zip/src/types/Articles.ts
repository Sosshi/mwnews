interface Article{
    id: number,
    heading: string,
    description: string,
    source: string,
    link: string,
    image: string,
    date: string
}

export default Article;